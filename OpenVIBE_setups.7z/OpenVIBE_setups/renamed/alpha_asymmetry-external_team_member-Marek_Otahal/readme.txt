Due to OpenVIBE crash file got corrupted. There are no links between the algorithms (boxes). It has to be reconnected, preferably by the creator and owner of the file - Marek Ot�hal from CTU FEL.

We (B-VR team) do not have permission to publish this file. It could be potentially granted by Marek Ot�hal.