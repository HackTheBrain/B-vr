Acquired during HackTheBrain Hackathon December 2-4 2016 Prague.

Original
- exactly what I got without my edits
- could be potentially used to find owners, timestamps, ...
Renamed
- restructed, renamed, translated, added readmes explaining ownership and Marek's corrupted file